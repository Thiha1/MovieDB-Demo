package com.android.demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.android.demo.Adapter.MovieAdapter;
import com.android.demo.Model.Movie;
import com.android.demo.Model.MoviesRepository;
import com.android.demo.Model.OnGetMoviesCallback;
import com.android.demo.Model.OnMovieClickCallback;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView moviesList;
    private MovieAdapter adapter;

    private MoviesRepository moviesRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        moviesRepository = MoviesRepository.getInstance();

        moviesList = findViewById(R.id.movies_list);
        moviesList.setHasFixedSize(true);

        moviesList.setLayoutManager(new GridLayoutManager(this,2));

        moviesRepository.getMovies(new OnGetMoviesCallback() {
            @Override
            public void onSuccess(List<Movie> movies) {
                adapter = new MovieAdapter(movies,callback);
                moviesList.setAdapter(adapter);
            }

            @Override
            public void onError() {
                Toast.makeText(MainActivity.this, "Please check your internet connection.", Toast.LENGTH_SHORT).show();
            }
        });


    }
        OnMovieClickCallback callback=new OnMovieClickCallback() {
            @Override
            public void onClick(Movie movie) {
                Intent intent= new Intent(MainActivity.this,DetailActivity.class);
                intent.putExtra(DetailActivity.MOVIE_ID,movie.getId());
                startActivity(intent);
            }
        };

}
