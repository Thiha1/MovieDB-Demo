package com.android.demo.Model;

public interface OnGetMovieCallback {
    void onSuccess(Movie movie);

    void onError();

}
