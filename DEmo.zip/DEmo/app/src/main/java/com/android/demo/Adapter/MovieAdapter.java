package com.android.demo.Adapter;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.demo.DetailActivity;
import com.android.demo.Model.Movie;
import com.android.demo.Model.OnGetMovieCallback;
import com.android.demo.Model.OnMovieClickCallback;
import com.android.demo.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;
public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private List<Movie> movies;
    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500";
    Context mContext;
    private OnMovieClickCallback callback;

    public MovieAdapter(List<Movie> movies,OnMovieClickCallback callback) {
        this.movies = movies;
        this.callback=callback;

    }

    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movie, parent, false);
        return new MovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MovieViewHolder holder, int position) {
        holder.bind(movies.get(position));
    }


    @Override
    public int getItemCount() {
        return movies.size();
    }

    class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView releaseDate;
        TextView title;
        TextView rating;
        TextView genres;
        ImageView poster;
        Movie movie;

        public MovieViewHolder(View itemView) {
            super(itemView);
           // Movie movies;
          //  releaseDate = itemView.findViewById(R.id.item_movie_release_date);
            title = itemView.findViewById(R.id.item_movie_title);
        //    rating = itemView.findViewById(R.id.item_movie_rating);
         //   genres = itemView.findViewById(R.id.item_movie_genre);
            poster=itemView.findViewById(R.id.item_movie_poster);

           // CardView recycler= itemView.findViewById(R.id.card);
           // recycler.setOnClickListener(this);

         itemView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
               callback.onClick(movie);
             }
         });

        }

        public void bind(Movie movie) {
            this.movie=movie;
          //  releaseDate.setText(movie.getReleaseDate().split("-")[0]);
            title.setText(movie.getTitle());
          //  rating.setText(String.valueOf(movie.getRating()));
         //   genres.setText("");
            Glide.with(itemView)
                    .load(IMAGE_BASE_URL+movie.getPosterPath())
                    .apply(RequestOptions.placeholderOf(R.color.colorAccent))
                    .into(poster);
        }


      /*  @Override
        public void onClick(View v) {
            int pos= getAdapterPosition();
            Movie clickedDataItem=movies.get(pos);
            Intent intent=new Intent(v.getContext(), DetailActivity.class);
            v.getContext().startActivity(intent);
            intent.putExtra("title","TTTTTT");
            intent.putExtra("image",movies.get(pos).getPosterPath());
            intent.putExtra("overview",movies.get(pos).getOverview());
           // intent.putExtra("release_date",movies.get(pos).getReleaseDate());
            intent.putExtra("rate",movies.get(pos).getRating());
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
           // mContext.startActivity(intent);
        }*/
    }
}