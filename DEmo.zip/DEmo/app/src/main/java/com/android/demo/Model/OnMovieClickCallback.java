package com.android.demo.Model;

public interface OnMovieClickCallback {
    void onClick(Movie movie);

}
